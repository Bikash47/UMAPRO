//**Color constants over the application */
/*export const BUTTON_COLOR = '#00CC67';
export const NAVIGATION_BAR_COLOR = '#00CC67';
export const STATUS_BAR_COLOR = '#00b75c';
export const HEADER_TEXT_COLOR = '#00cc67';
// export const MODAL_BG_COLOR = "#005400";
export const MODAL_BG_COLOR = "#009249";
// export const COMMON_GREEN_COLOR = "#146514";
export const COMMON_GREEN_COLOR = "rgba(20,101,20,0.9)";*/


// export const NAVIGATION_DRAWER_BACKGROUND_COLOR = '#363B4D';
export const NAVIGATION_DRAWER_BACKGROUND_COLOR = '#26344B';
export const NAVIGATION_DRAWER_SELECTED_ITEM_BACKGROUND_COLOR = '#212D41';
export const FONT_FAMILY = "normal";
export const FONT_FAMILY_BOLD = "bold";


export const BUTTON_COLOR = '#00CC67';
export const NAVIGATION_BAR_COLOR = '#00CC67';
export const STATUS_BAR_COLOR = '#af2e2f'; 
// STATUS_BAR_COLOR: '#ffffff'
export const HEADER_TEXT_COLOR = '#00cc67';
// export const MODAL_BG_COLOR = "#005400";
export const MODAL_BG_COLOR = "#ffffff";
// export const MODAL_BG_COLOR = "#d8241c";

export const COMMON_GREEN_COLOR = "#605d5c";