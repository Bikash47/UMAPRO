export function addingTwoValue(x: number, y: number): number {
    var res: number;
    res = x + y;
    return res;
}