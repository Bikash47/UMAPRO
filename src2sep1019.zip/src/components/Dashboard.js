import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    TextInput,
    TouchableOpacity,
    View,
    NetInfo,
    TouchableHighlight,
    ScrollView,
    RefreshControl,
    Image,
    ImageBackground,
    Dimensions,
    BackHandler,
    StatusBar, FlatList,
    Platform, AsyncStorage, Easing, TouchableNativeFeedback, PermissionsAndroid,ActivityIndicator
} from "react-native";
import { ProgressBar } from "./common";
import { Actions } from 'react-native-router-flux';
import { connect } from 'react-redux';
import RNExitApp from 'react-native-exit-app';
// import {GRIEVANCES, PROFILE,MYCARDS} from "../config/Config";
import Snackbar from 'react-native-snackbar';
import { FONT_FAMILY, FONT_FAMILY_BOLD, STATUS_BAR_COLOR } from '../config/ConfigStyle';
import * as Animatable from 'react-native-animatable';
import * as MagicMove from "react-native-magic-move";

MyCustomTouchableOpacity = MagicMove.createMagicMoveComponent(TouchableOpacity);

class Dashboard extends React.PureComponent {
    constructor(props) {
        super(props);
    }

    componentWillMount() {
        BackHandler.addEventListener('hardwareBackPress', this.onBackPress.bind(this));
    }
    componentDidMount() { }
    componentWillUnmount() {
        BackHandler.removeEventListener('hardwareBackPress', this.onBackPress.bind(this));
    }
    onBackPress() {
        // debugger;
        if (Actions.currentScene === 'Dashboard') {
            Snackbar.show({
                title: 'Press EXIT to close the app',
                duration: Snackbar.LENGTH_SHORT,
                color: 'white',
                action: {
                    title: 'EXIT',
                    color: 'red',
                    onPress: () => {
                        RNExitApp.exitApp();
                    },
                },
            });

            return true;
        }
        return false;
    }

    func_stillWorking() {
        Snackbar.show({
            title: 'We are currently working on it',
            color: 'white',
            duration: Snackbar.LENGTH_SHORT,
            action: {
                title: 'EXIT',
                color: 'red',
                onPress: () => {
                    RNExitApp.exitApp();
                },
            },
        });
    }

    render() {
        debugger;
        console.log(this.props.logoutLoading);
        return (
            <MagicMove.Scene style={style.container}>

                {!this.props.logoutLoading ? <View style={style.container}>
                    <StatusBar hidden={false} />
                    <ScrollView scrollEnabled={false}
                        contentContainerStyle={{ flexGrow: 1, justifyContent: 'flex-start', alignItems: 'center' }}>
                        <Animatable.View animation="fadeInUpBig"
                            useNativeDriver
                            delay={500}
                            style={{
                                height: Dimensions.get("window").height - 120,
                                width: Dimensions.get("window").width - 40,
                                backgroundColor: STATUS_BAR_COLOR,
                            }}>
                            {/* 1st row */}
                            <View style={[style.Boxes, style.BoxesForRows]}>

                                <MyCustomTouchableOpacity id="Crop Diversification" transition={MagicMove.Transition.flip} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.CropDiversificationForm()} style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/crop.png")}//18604195555 1860500  PPR002402386980
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>CD</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>
                                <MyCustomTouchableOpacity id="Homestead Kitchen Garden" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.HomesteadKitchenGardenDataForm()} style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/hkg.png")}//18604195555 1860500  PPR002402386980
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>HKG</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>

                                <MyCustomTouchableOpacity id="Labour Saving Technology" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.LabourSavingTechnologyForm()}
                                    style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/labour-saving.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>LST</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>


                            </View>

                            {/* 2nd row */}

                            <View style={[style.Boxes, style.BoxesForRows]}>
                                <MyCustomTouchableOpacity id="Livestock Goatery" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.LivestockGoateryDataForm()}
                                    style={style.separateBoxes}>
                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image source={require("../imgs/goateryUntitled-2.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>LSG</Text>
                                        </View>
                                    </View>
                                </MyCustomTouchableOpacity>
                                <MyCustomTouchableOpacity id="Livestock Poultry" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.LivestockPoultryForm()} style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/poultry.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text numberOfLines={1} style={style.TextStyle}>LSP</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>

                                <MyCustomTouchableOpacity id="Livestock Diary" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.LivestockDiaryForm()}
                                    style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/dairy.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>LSD</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>
                            </View>


                            {/* 3rd row */}
                            <View style={[style.Boxes, style.BoxesForRows]}>
                                <MyCustomTouchableOpacity id="Post Harvest Loss Reduction" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.PostHarvestLossReductionForm()}
                                    style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/harvest-loss.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>PHLR</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>
                                <MyCustomTouchableOpacity id="Strengthening Women Leadership" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.StrengtheningWomenLeadershipForm()}
                                    style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/swl.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>SWL</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>
                                <MyCustomTouchableOpacity id="Training Tracking" transition={MagicMove.Transition.morph} easing={Easing.inOut(Easing.ease)} onPress={() => Actions.TrainingTrackingForm()}
                                    style={style.separateBoxes}>

                                    <View style={style.separateInnerBox}>
                                        <View style={style.imageWrapper}>
                                            <Image
                                                source={require("../imgs/training.png")}
                                                style={style.Icons}
                                            />
                                        </View>
                                        <View style={style.textWrapper}>
                                            <Text style={style.TextStyle}>TT</Text>
                                        </View>
                                    </View>

                                </MyCustomTouchableOpacity>

                            </View>
                        </Animatable.View>
                    </ScrollView>

                </View> :<ActivityIndicator size="large" color="#ffffff" />}
            </MagicMove.Scene>

        );
    }
}
const mapStateToProps = ({ formtt }) => {
    // email:auth.state.email;
    const {
      logoutLoading
    } = formtt;
    return {  logoutLoading };
  };
  
const style = {
    container: {
        flex: 1,
        backgroundColor: '#af2e2f'
    },
    BackgroundImage: {
        flex: 1,
        alignSelf: "stretch",
        width: null,
        justifyContent: "center"
    },
    containerBody: {
        height: (Dimensions.get('window').height) - 80,
        margin: 30,
        justifyContent: "space-between",
    },
    Boxes: {
        flex: 1,
        backgroundColor: "rgba(255,255,255,0)"

    },
    BoxesForRows: {
        flexDirection: "row",
        justifyContent: "space-between"
    },
    separateBoxes: {
        flex: 1,
        backgroundColor: "rgba(255,255,255,0.2)",
        margin: 2,
        borderRadius: 5,
        justifyContent: "center",
        alignItems: "center", padding: 20
    },
    separateInnerBox: {
        flex: 1,
        // justifyContent: "center",
        // alignItems: "center"
    },
    imageWrapper: { flex: 0.6, justifyContent: 'flex-end', alignItems: 'center', backgroundColor: 'transparent' },
    textWrapper: { flex: 0.4, justifyContent: 'flex-start', alignItems: 'center', backgroundColor: 'transparent' },
    Icons: {
        height: 50,
        width: 50

    },
    TextStyle: {
        marginTop: 5,
        color: "#fff",
        fontWeight: "400",
        fontSize: 15,
        fontFamily: FONT_FAMILY,
        textAlign: "center", marginHorizontal: 5
    },
    feedbackView: {
        flex: 1,
        backgroundColor: "rgba(255,255,255,0.2)",
        margin: 4,
        borderRadius: 5
    }
};
export default connect(mapStateToProps,{})(Dashboard);
//**Module Full Names */

// Crop Diversification
// Homestead Kitchen Garden Form
// Labour Saving Technology Form
// Livestock-Goatery Form
// Livestock-Polutry Form
// Livestock-Diary Form
// Post Harvest Loss Reduction Form
// Strengthening Women Leadership Form
// Training Ticket Form